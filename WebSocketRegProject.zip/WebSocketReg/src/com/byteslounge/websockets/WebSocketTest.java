package com.byteslounge.websockets;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/websocket")
public class WebSocketTest {

	private static Set<Session> clients = Collections.synchronizedSet(new HashSet<Session>());
	private static HashMap<Session ,String> users = new HashMap<Session, String>();
	private static HashMap<String ,String> usr = new HashMap<String, String>();
	@OnMessage
    public void onMessage(String message, Session session) 
    	throws IOException {

		users.put(session, message);
		synchronized(clients){

			String allUser = "";
			
			for ( Map.Entry<Session, String> entry : users.entrySet()) {
			    String tab = entry.getValue();
			    if (usr.get(tab) == null){
			    	allUser +=  tab + ",";
			    	usr.put(tab, tab);
			    }
			}
			
			usr = new HashMap<String, String>();
			
			for(Session client : clients){
					client.getBasicRemote().sendText(allUser);
			}
			
		}
    }
	
	@OnOpen
    public void onOpen (Session session) {
		// Add session to the connected sessions set
		clients.add(session);
    }

    @OnClose
    public void onClose (Session session) {
    	// Remove session from the connected sessions set
    	clients.remove(session);
    }
}
